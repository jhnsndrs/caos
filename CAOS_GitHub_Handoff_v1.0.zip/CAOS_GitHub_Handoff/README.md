# CAOS GitHub Handoff

Upload this complete folder to a **public GitHub repository**.

## Files

- `prototype/index.html` — visual prototype entry point
- `prototype/styles.css` — prototype styling
- `prototype/app.js` — prototype interactions and demo data
- `prototype/INTERACTION_SPEC.md` — original interaction notes
- `SCREEN_SPECIFICATIONS.md` — approved 14-screen description
- `ITTT_WORKFLOWS.md` — cross-application business rules
- `BASE44_BUILD_PROMPT.md` — exact instruction to give Base44

## What to send Base44

Because Base44 can fetch public raw GitHub files, send the raw URLs for:

1. `BASE44_BUILD_PROMPT.md`
2. `SCREEN_SPECIFICATIONS.md`
3. `ITTT_WORKFLOWS.md`
4. `prototype/index.html`
5. `prototype/styles.css`
6. `prototype/app.js`

Ask Base44 to first confirm it read every file before it begins building.
